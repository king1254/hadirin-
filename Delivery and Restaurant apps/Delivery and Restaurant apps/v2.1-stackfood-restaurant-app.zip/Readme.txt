If you need only the changed files for restaurant app in V2.1 check the Restaurant app changed files from V2.0 to V2.1 folder 
otherwise please use the restaurant app folder.