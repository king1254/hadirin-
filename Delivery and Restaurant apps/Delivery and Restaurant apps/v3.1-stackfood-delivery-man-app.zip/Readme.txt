If you need only the changed files for Delivery Man app in V3.1 check the Delivery app changed files from V3.0 to V3.1 folder 
otherwise please use the delivery man app folder.